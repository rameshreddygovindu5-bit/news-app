from app.database import SyncSessionLocal
from app.models.models import Category

def seed():
    session = SyncSessionLocal()
    categories = [
        "Politics", "Business", "Technology", "Sports", "Entertainment",
        "Health", "Science", "Education", "Crime", "International",
        "Environment", "Lifestyle", "Religion", "Agriculture", "Home"
    ]
    try:
        # Deactivate all others or ensure these 15 are active
        for name in categories:
            slug = name.lower()
            existing = session.query(Category).filter(Category.name == name).first()
            if not existing:
                print(f"Adding new category: {name}")
                session.add(Category(name=name, slug=slug, is_active=True))
            else:
                print(f"Ensuring active: {name}")
                existing.is_active = True
        
        session.commit()
        print(f">>> SUCCESS: Seeded {len(categories)} categories.")
    except Exception as e:
        session.rollback()
        print(f">>> ERROR: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    seed()
