import asyncio
import logging
from datetime import datetime, timezone
from app.scrapers.cnn_scraper import CNNScraper
from app.database import SyncSessionLocal
from app.models.models import NewsArticle, NewsSource

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("CNN_DEBUG")

async def run_scrape():
    db = SyncSessionLocal()
    cnn_src = db.query(NewsSource).get(13)
    if not cnn_src:
        logger.error("Source 13 NOT FOUND")
        return

    config = {
        "name": cnn_src.name,
        "url": cnn_src.url,
        "scraper_type": "cnn",
        "language": cnn_src.language,
        "scraper_config": cnn_src.scraper_config or {}
    }
    
    logger.info(f"Starting scrape for {cnn_src.name}...")
    scraper = CNNScraper(config)
    articles = await scraper.scrape()
    logger.info(f"Scraper returned {len(articles)} articles.")

    for i, a in enumerate(articles):
        # Check if already exists to avoid duplicates
        existing = db.query(NewsArticle).filter(NewsArticle.original_url == a.url).first()
        if existing:
            continue
            
        new_art = NewsArticle(
            source_id=13,
            original_title=a.title,
            original_content=a.content or a.title,
            original_url=a.url,
            published_at=a.published_at or datetime.now(timezone.utc),
            image_url=a.image_url,
            flag="Y",
            ai_status="completed",
            rephrased_title=a.title,
            rephrased_content=a.content or a.title,
            category="Home",
            slug=f"cnn-{i}-{int(datetime.now().timestamp())}"
        )
        db.add(new_art)
    
    db.commit()
    logger.info("Database committed successfully.")
    
    final_count = db.query(NewsArticle).filter(NewsArticle.source_id == 13).count()
    logger.info(f"Final article count for CNN in DB: {final_count}")
    db.close()

if __name__ == "__main__":
    asyncio.run(run_scrape())
