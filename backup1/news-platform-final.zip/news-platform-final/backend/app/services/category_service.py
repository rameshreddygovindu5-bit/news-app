"""
Category Service — Single source of truth for all category normalization.

CANONICAL_CATEGORIES must stay in sync with:
  - config.py  Settings.CATEGORIES
  - Frontend   CATS in App.js
"""
from typing import List, Dict
import logging

logger = logging.getLogger(__name__)

# ─── CANONICAL CATEGORY LIST ───────────────────────────────────────────────
# THIS IS THE MASTER LIST. Update config.py and App.js together when changing.
CANONICAL_CATEGORIES: List[str] = [
    "Politics",
    "Business",
    "Technology",
    "Sports",
    "Entertainment",
    "Health",
    "Science",
    "Education",
    "Crime",
    "International",
    "Environment",
    "Lifestyle",
    "Religion",
    "Agriculture",
    "Home",
]

# ─── ALIAS → CANONICAL MAPPING ─────────────────────────────────────────────
# Keys are lowercase aliases; values are canonical names from the list above.
CATEGORY_MAP: Dict[str, str] = {
    # Technology
    "technology": "Technology",
    "science & technology": "Technology",
    "sci-tech": "Technology",
    "it": "Technology",
    "tech": "Technology",
    "ai": "Technology",
    "gadgets": "Technology",
    "innovation": "Technology",

    # International
    "international": "International",
    "global": "International",
    "foreign": "International",
    "world news": "International",
    "world": "International",
    "international news": "International",

    # Politics
    "government": "Politics",
    "elections": "Politics",
    "election": "Politics",
    "policy": "Politics",
    "political": "Politics",
    "andhra-news": "Politics",
    "telangana-news": "Politics",
    "india-news": "Politics",
    "national": "Politics",

    # Business / Economy
    "finance": "Business",
    "economy": "Business",
    "market": "Business",
    "markets": "Business",
    "stocks": "Business",
    "investment": "Business",
    "trade": "Business",
    "economic": "Business",
    "money": "Business",

    # Entertainment
    "movies": "Entertainment",
    "movie": "Entertainment",
    "film": "Entertainment",
    "films": "Entertainment",
    "cinema": "Entertainment",
    "bollywood": "Entertainment",
    "tollywood": "Entertainment",
    "hollywood": "Entertainment",
    "television": "Entertainment",
    "tv": "Entertainment",
    "music": "Entertainment",
    "celebrity": "Entertainment",
    "gossip": "Entertainment",
    "culture": "Entertainment",
    "arts": "Entertainment",
    "lifestyle": "Entertainment",
    "fashion": "Entertainment",
    "style": "Entertainment",
    "reviews": "Entertainment",

    # Health
    "medical": "Health",
    "medicine": "Health",
    "wellness": "Health",
    "fitness": "Health",
    "covid": "Health",
    "disease": "Health",
    "healthcare": "Health",

    # Science
    "research": "Science",
    "space": "Science",
    "nature": "Science",
    "environment": "Science",
    "climate": "Science",
    "ecology": "Science",

    # Sports / Events
    "sports": "Sports",
    "sport": "Sports",
    "cricket": "Sports",
    "football": "Sports",
    "soccer": "Sports",
    "tennis": "Sports",
    "basketball": "Sports",
    "kabaddi": "Sports",
    "ipl": "Sports",
    "events": "Events",
    "festivals": "Events",
    "festival": "Events",
    "event": "Events",

    # New Categories
    "education": "Education",
    "crime": "Crime",
    "scam": "Crime",
    "fraud": "Crime",
    "police": "Crime",
    "lifestyle": "Lifestyle",
    "fashion": "Lifestyle",
    "style": "Lifestyle",
    "religion": "Religion",
    "devotional": "Religion",
    "spiritual": "Religion",
    "agriculture": "Agriculture",
    "farming": "Agriculture",
    "farmer": "Agriculture",

    # Home / General
    "general": "Home",
    "breaking": "Home",
    "top news": "Home",
    "latest": "Home",
    "news": "Home",
    "local": "Home",
    "opinion": "Home",
    "analysis": "Home",
    "mbs": "Home",
    "other": "Home",
}


class CategoryService:
    """Normalize any raw category string to a canonical category name."""

    @staticmethod
    def normalize(cat: str) -> str:
        """
        Returns the canonical category for a raw string.
        Priority:
          1. Exact match (case-insensitive) against canonical list.
          2. Exact key match in CATEGORY_MAP.
          3. Substring match in CATEGORY_MAP.
          4. Fallback → "Home".
        """
        if not cat:
            return "Home"

        c = cat.strip().lower()

        # 1. Exact canonical match
        for canon in CANONICAL_CATEGORIES:
            if canon.lower() == c:
                return canon

        # 2. Direct alias map
        if c in CATEGORY_MAP:
            return CATEGORY_MAP[c]

        # 3. Partial / substring match
        for key, val in CATEGORY_MAP.items():
            if key in c or c in key:
                return val

        logger.debug(f"[CategoryService] Unknown category '{cat}', defaulting to Home")
        return "Home"

    @staticmethod
    def get_all() -> List[str]:
        """Return the full canonical list."""
        return list(CANONICAL_CATEGORIES)

    @staticmethod
    def is_valid(cat: str) -> bool:
        """True if already a canonical category name."""
        return cat in CANONICAL_CATEGORIES


category_service = CategoryService()
