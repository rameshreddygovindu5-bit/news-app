"""
News Aggregation Platform — FastAPI Application Entry Point

Startup sequence:
  1. DB connection pool initialised
  2. APScheduler (in-process fallback) started
  3. CORS configured from settings.CORS_ORIGINS
  4. All API routers registered

Use Celery Beat + Worker for production scheduling.
APScheduler is a lightweight fallback for development / single-process deploys.
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.api import all_routers

settings = get_settings()

logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"═══ Starting {settings.APP_NAME} v{settings.APP_VERSION} ═══")

    # Start in-process fallback scheduler (no-op if Celery Beat is running)
    try:
        from app.tasks.scheduler import start_scheduler, stop_scheduler
        start_scheduler()
        logger.info("[SCHEDULER] In-process scheduler started")
    except Exception as exc:
        logger.warning(f"[SCHEDULER] Could not start in-process scheduler: {exc}")
        stop_scheduler = lambda: None  # noqa

    yield

    try:
        stop_scheduler()
    except Exception:
        pass
    logger.info("═══ Shutdown complete ═══")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "AI-powered news aggregation platform — "
        "scraping, translation, rephrasing, categorisation, AWS sync."
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS — merge hardcoded dev origins with config-driven origins
_cors_origins = list(
    set(
        [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:3001",
            "http://127.0.0.1:3001",
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ]
        + list(settings.CORS_ORIGINS)
    )
)

# Permissive CORS for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Register all API routers
for router in all_routers:
    app.include_router(router)


# ── Core endpoints ────────────────────────────────────────────────────

@app.get("/", tags=["Core"])
async def root():
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
    }


@app.get("/health", tags=["Core"])
async def health():
    """Health check — used by Docker HEALTHCHECK and load-balancers."""
    return {"status": "healthy", "version": settings.APP_VERSION}
