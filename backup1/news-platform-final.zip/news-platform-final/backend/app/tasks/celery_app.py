"""
Celery Task Queue — News Pipeline
==================================
Pipeline order (each job runs after the previous completes):
  1. scrape_all_sources   — pull raw articles from all scrapers
  2. process_ai_batch     — AI rephrase + categorise + tag + slug
  3. update_top_100       — calculate rank scores; mark best 100 as Y
  4. sync_to_aws          — delta-push local DB → AWS production DB
  5. update_category_counts — refresh category article counters
  6. cleanup_old_articles — soft-delete articles older than 15 days
  7. post_to_social       — post Y-flag articles to FB / X / IG / WA

All jobs use a distributed DB-backed lock to prevent double-execution.
Beat schedule is built dynamically from config flags so individual jobs
can be enabled/disabled from the Admin UI without restarting workers.

Key fixes in this version:
  - Added missing `desc` SQLAlchemy import
  - Re-enabled sync_to_aws in beat schedule and run_full_pipeline
  - Crontab schedule correctly passes comma-separated minute strings
  - Added pipeline start/stop lifecycle logging with timestamps
  - Scheduler stops cleanly after each run (no dangling locks)
"""

import asyncio
import logging
import time
import uuid
import hashlib
import re
import datetime
from datetime import timezone, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Dict

from celery import Celery
from celery.schedules import crontab
from sqlalchemy import select, update, func, and_, or_, text, desc  # ← desc added
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import SyncSessionLocal
from app.models.models import (
    NewsSource, NewsArticle, Category, JobExecutionLog,
    PostErrorLog, SyncMetadata, SourceErrorLog,
)
from app.scrapers.base_scraper import ScraperFactory
from app.services.ai_service import ai_service
from app.services.social_service import social_service
import psycopg2
import psycopg2.extras

logger = logging.getLogger(__name__)
settings = get_settings()


# =============================================
# CELERY APPLICATION
# =============================================

celery_app = Celery(
    "news_aggregator",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_soft_time_limit=3600,   # 1-hour soft limit
    task_time_limit=7200,        # 2-hour hard kill
    worker_hijack_root_logger=False,
    broker_connection_retry_on_startup=True,
)


# =============================================
# DYNAMIC BEAT SCHEDULE
# =============================================

def _build_crontab(minutes_str: str) -> crontab:
    """
    Build a Celery crontab from a comma-separated minute string.
    E.g. "0,30" → crontab(minute="0,30")  (runs at :00 and :30 every hour)
    """
    if not minutes_str:
        return crontab(minute="0")
    return crontab(minute=str(minutes_str))


def build_beat_schedule() -> dict:
    """Build Celery Beat schedule from config flags."""
    schedule = {}

    if not settings.SCHEDULER_ENABLED:
        logger.info("[SCHEDULER] Master switch OFF — all jobs disabled")
        return schedule

    jobs = [
        (
            "scrape-all-sources",
            settings.SCHEDULE_SCRAPE_ENABLED,
            "app.tasks.celery_app.scrape_all_sources",
            settings.SCHEDULE_SCRAPE_MINUTES,
        ),
        (
            "process-ai-batch",
            settings.SCHEDULE_AI_ENABLED,
            "app.tasks.celery_app.process_ai_batch",
            settings.SCHEDULE_AI_MINUTES,
        ),
        (
            "update-top-100",
            settings.SCHEDULE_RANKING_ENABLED,
            "app.tasks.celery_app.update_top_100_ranking",
            settings.SCHEDULE_RANKING_MINUTES,
        ),
        (
            "sync-to-aws",                          # ← re-enabled
            settings.SCHEDULE_AWS_SYNC_ENABLED,
            "app.tasks.celery_app.sync_to_aws",
            settings.SCHEDULE_AWS_SYNC_MINUTES,
        ),
        (
            "update-category-counts",
            settings.SCHEDULE_CATEGORY_COUNT_ENABLED,
            "app.tasks.celery_app.update_category_counts",
            settings.SCHEDULE_CATEGORY_MINUTES,
        ),
        (
            "cleanup-old-articles",
            settings.SCHEDULE_CLEANUP_ENABLED,
            "app.tasks.celery_app.cleanup_old_articles",
            settings.SCHEDULE_CLEANUP_MINUTES,
        ),
        (
            "post-to-social",
            settings.SCHEDULE_SOCIAL_ENABLED,
            "app.tasks.celery_app.post_to_social",
            settings.SCHEDULE_SOCIAL_MINUTES,
        ),
    ]

    for key, enabled, task_path, minutes in jobs:
        if enabled:
            schedule[key] = {
                "task": task_path,
                "schedule": _build_crontab(minutes),
            }
            logger.info(f"[SCHEDULER] ON  ▶ {key:<32} @ minute(s) {minutes}")
        else:
            logger.info(f"[SCHEDULER] OFF ■ {key}")

    return schedule


celery_app.conf.beat_schedule = build_beat_schedule()


# =============================================
# DATABASE SESSION HELPER
# =============================================

def get_db() -> Session:
    return SyncSessionLocal()


# =============================================
# DISTRIBUTED JOB-LOCK FRAMEWORK
# =============================================

def log_job(db: Session, job_name: str, triggered_by: str = "cron") -> Optional[JobExecutionLog]:
    """
    Acquire an idempotency lock for `job_name`.
    Uses an atomic SQL INSERT … WHERE NOT EXISTS to avoid double-execution.
    Stale locks (> 2 hours) are forcibly failed before attempting acquisition.
    Returns the JobExecutionLog row or None if already running.
    """
    run_id = str(uuid.uuid4())

    # Clean up stale locks
    stale_cutoff = datetime.datetime.now(timezone.utc) - timedelta(hours=2)
    db.execute(
        update(JobExecutionLog)
        .where(
            JobExecutionLog.status == "RUNNING",
            JobExecutionLog.started_at < stale_cutoff,
        )
        .values(status="FAILED", ended_at=func.now(), error_summary="Stale lock auto-failed")
    )
    db.commit()

    # Atomic lock acquisition
    sql = text("""
        INSERT INTO job_execution_log (job_name, run_id, started_at, status, triggered_by)
        SELECT :name, :id, NOW(), 'RUNNING', :trigger
        WHERE NOT EXISTS (
            SELECT 1 FROM job_execution_log
            WHERE job_name = :name AND status = 'RUNNING'
        )
        RETURNING id;
    """)
    result = db.execute(sql, {"name": job_name, "id": run_id, "trigger": triggered_by}).fetchone()
    if not result:
        logger.info(f"[JOB] {job_name} is already RUNNING — skipping duplicate.")
        return None

    db.commit()
    return db.query(JobExecutionLog).get(result[0])


def complete_job(
    db: Session,
    log: Optional[JobExecutionLog],
    rows_ok: int,
    rows_err: int,
    error_summary: str = None,
):
    """Finalise a job run and release its lock."""
    if not log:
        return
    status = "DONE"
    if rows_err > 0:
        status = "PARTIAL" if rows_ok > 0 else "FAILED"
    log.status = status
    log.rows_ok = rows_ok
    log.rows_err = rows_err
    log.error_summary = error_summary
    log.ended_at = datetime.datetime.now(timezone.utc)
    log.duration_s = (log.ended_at - log.started_at).total_seconds()
    db.commit()
    logger.info(
        f"[JOB] {log.job_name} → {status} "
        f"(ok={rows_ok}, err={rows_err}, {log.duration_s:.1f}s)"
    )


# =============================================
# UTILITY
# =============================================

def normalize_title(title: str) -> str:
    if not title:
        return ""
    return re.sub(r"[^\w\s]", "", title.lower()).strip()


def get_content_hash(source_id: int, title: str) -> str:
    return hashlib.sha256(f"{source_id}{normalize_title(title)}".encode()).hexdigest()


def _pipeline_banner(label: str, start: bool = True):
    bar = "=" * 60
    verb = "STARTING" if start else "COMPLETED"
    logger.info(f"\n{bar}\n  {verb}: {label}\n  Time: {datetime.datetime.now(timezone.utc).isoformat()}\n{bar}")


# =============================================
# TASK 1: SCRAPING
# =============================================

@celery_app.task(name="app.tasks.celery_app.scrape_all_sources")
def scrape_all_sources():
    _pipeline_banner("SCRAPE ALL SOURCES")
    db = get_db()
    log = log_job(db, "scrape_sources")
    if not log:
        return
    try:
        q = db.query(NewsSource).filter(
            NewsSource.is_enabled == True,
            NewsSource.is_paused == False,
        )
        if settings.ENABLED_SOURCES:
            names = [s.strip().lower() for s in settings.ENABLED_SOURCES.split(",")]
            q = q.filter(func.lower(NewsSource.name).in_(names))
        sources = q.all()

        if not sources:
            complete_job(db, log, 0, 0, "No active sources")
            return

        ok = err = 0
        with ThreadPoolExecutor(max_workers=16) as pool:
            futures = {
                pool.submit(worker_scrape_source, s.id, log.run_id): s
                for s in sources
            }
            for future in as_completed(futures):
                res = future.result()
                ok += res.get("inserted", 0)
                err += res.get("errors", 0)

        complete_job(db, log, ok, err)
    except Exception as exc:
        logger.error(f"[SCRAPE] Fatal error: {exc}")
        complete_job(db, log, 0, 1, str(exc))
    finally:
        db.close()
    _pipeline_banner("SCRAPE ALL SOURCES", start=False)


@celery_app.task(name="app.tasks.celery_app.scrape_source")
def scrape_source(source_id: int):
    """Manually trigger a scrape for a single source."""
    db = get_db()
    try:
        source = db.query(NewsSource).get(source_id)
        if not source:
            return
        log = log_job(db, f"scrape_{source.name.lower()}", "manual")
        if not log:
            return
        res = worker_scrape_source(source_id, log.run_id)
        complete_job(db, log, res.get("inserted", 0), res.get("errors", 0))
    finally:
        db.close()


def worker_scrape_source(source_id: int, run_id: str) -> Dict:
    """Thread worker: scrape one source and persist articles."""
    db = SyncSessionLocal()
    stats = {"inserted": 0, "errors": 0}
    try:
        source = db.query(NewsSource).get(source_id)
        if not source:
            return stats

        scraper = ScraperFactory.create({
            "name": source.name,
            "url": source.url,
            "scraper_type": source.scraper_type,
            "language": source.language,
            "scraper_config": source.scraper_config or {},
        })

        loop = asyncio.new_event_loop()
        try:
            articles = loop.run_until_complete(scraper.scrape())
        finally:
            loop.close()

        for a in articles:
            c_hash = get_content_hash(source_id, a.title)

            # Skip exact duplicates (same normalised title + source)
            if db.query(NewsArticle.id).filter(NewsArticle.content_hash == c_hash).first():
                continue

            # Near-duplicate detection via pg_trgm similarity
            is_dup = False
            dup_id = None
            try:
                sql = text("""
                    SELECT id FROM news_articles
                    WHERE created_at > NOW() - INTERVAL '48 hours'
                      AND is_duplicate = FALSE
                      AND similarity(original_title, :t) > 0.85
                    LIMIT 1
                """)
                match = db.execute(sql, {"t": a.title}).fetchone()
                if match:
                    is_dup = True
                    dup_id = match[0]
            except Exception:
                pass  # pg_trgm may not be installed; skip soft-dup check

            clean = re.sub(r"[^\w\s-]", "", a.title.lower()).strip().replace(" ", "-")[:100]
            url_hash = hashlib.md5(a.url.encode()).hexdigest()[:6]
            slug = f"{clean}-{url_hash}"

            new_art = NewsArticle(
                source_id=source_id,
                original_title=a.title,
                original_content=a.content or a.title,
                original_url=a.url,
                original_language=source.language or "en",
                published_at=a.published_at or datetime.datetime.now(timezone.utc),
                image_url=a.image_url,
                content_hash=c_hash,
                is_duplicate=is_dup,
                duplicate_of_id=dup_id,
                flag="A",
                ai_status="pending",
                rephrased_title=a.title,
                rephrased_content=a.content or a.title,
                category="Home",
                slug=slug,
            )
            db.add(new_art)
            db.commit()
            stats["inserted"] += 1

        source.last_scraped_at = datetime.datetime.now(timezone.utc)
        db.commit()
        logger.info(f"[SCRAPE] {source.name}: +{stats['inserted']} articles")

    except Exception as exc:
        logger.error(f"[SCRAPE] Source {source_id} error: {exc}")
        stats["errors"] = 1
    finally:
        db.close()
    return stats


# =============================================
# TASK 2: AI ENRICHMENT
# =============================================

@celery_app.task(name="app.tasks.celery_app.process_ai_batch")
def process_ai_batch():
    _pipeline_banner("AI ENRICHMENT BATCH")
    db = get_db()
    log = log_job(db, "ai_enrichment")
    if not log:
        return
    try:
        # Atomically claim a batch
        subq = (
            db.query(NewsArticle.id)
            .filter(
                NewsArticle.ai_status.in_(["pending", "unknown"]),
                NewsArticle.is_duplicate == False,
            )
            .order_by(func.random())
            .limit(settings.AI_BATCH_SIZE)
            .subquery()
        )
        db.execute(
            update(NewsArticle)
            .where(NewsArticle.id.in_(select(subq)))
            .values(ai_status="processing")
        )
        db.commit()

        articles = db.query(NewsArticle).filter(NewsArticle.ai_status == "processing").all()
        if not articles:
            complete_job(db, log, 0, 0, "No pending articles")
            return

        ok = err = 0
        max_workers = min(settings.AI_CONCURRENCY, 10)
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(worker_process_ai, a.id) for a in articles]
            for f in as_completed(futures):
                if f.result():
                    ok += 1
                else:
                    err += 1

        complete_job(db, log, ok, err)
    except Exception as exc:
        logger.error(f"[AI] Fatal: {exc}")
        complete_job(db, log, 0, 1, str(exc))
    finally:
        db.close()
    _pipeline_banner("AI ENRICHMENT BATCH", start=False)


def worker_process_ai(article_id: int) -> bool:
    """Thread worker: AI-process a single article."""
    db = SyncSessionLocal()
    try:
        art = db.query(NewsArticle).get(article_id)
        if not art:
            return False
        res = ai_service.process_article(art.original_title, art.original_content or "")
        art.rephrased_title = res["rephrased_title"]
        art.rephrased_content = res["rephrased_content"]
        art.category = res["category"]
        art.slug = res.get("slug") or art.slug
        art.tags = res.get("tags", [])
        art.telugu_title = res.get("telugu_title")
        art.telugu_content = res.get("telugu_content")
        art.ai_status = "completed"
        art.flag = "A"
        art.processed_at = func.now()
        meta = dict(art.scrape_metadata or {})
        meta["ai_method"] = res.get("method", "unknown")
        art.scrape_metadata = meta
        db.commit()
        return True
    except Exception as exc:
        logger.error(f"[AI] Article {article_id} failed: {exc}")
        db.rollback()
        db.execute(
            update(NewsArticle)
            .where(NewsArticle.id == article_id)
            .values(ai_status="failed", ai_error_count=NewsArticle.ai_error_count + 1)
        )
        db.commit()
        return False
    finally:
        db.close()


# =============================================
# TASK 3: TOP-100 RANKING
# =============================================

@celery_app.task(name="app.tasks.celery_app.update_top_100_ranking")
def update_top_100_ranking():
    _pipeline_banner("TOP-100 RANKING")
    db = get_db()
    log = log_job(db, "ranking")
    if not log:
        return
    try:
        # Reset existing top-news flags
        db.execute(update(NewsArticle).where(NewsArticle.flag == "Y").values(flag="A"))
        db.commit()

        # Find candidates — expand time window until we have enough
        candidate_articles = []
        for days in [2, 7, 30, 60, 90]:
            cutoff = datetime.datetime.now(timezone.utc) - timedelta(days=days)
            candidate_articles = (
                db.query(NewsArticle)
                .join(NewsSource)
                .filter(
                    NewsArticle.ai_status == "completed",
                    NewsArticle.created_at >= cutoff,
                    NewsArticle.is_duplicate == False,
                    NewsArticle.flag.in_(["A", "Y"]),
                )
                .all()
            )
            if len(candidate_articles) >= 150:
                break

        if not candidate_articles:
            # Hard fallback
            candidate_articles = (
                db.query(NewsArticle)
                .join(NewsSource)
                .filter(
                    NewsArticle.ai_status == "completed",
                    NewsArticle.is_duplicate == False,
                    NewsArticle.flag.in_(["A", "Y"]),
                )
                .order_by(desc(NewsArticle.created_at))   # ← uses imported desc
                .limit(200)
                .all()
            )

        if not candidate_articles:
            complete_job(db, log, 0, 0, "No candidates")
            return

        # Score each article
        now = datetime.datetime.now(timezone.utc)
        for a in candidate_articles:
            age_hours = (now - a.created_at).total_seconds() / 3600
            a.rank_score = (
                (a.source.priority * 15)
                + (a.source.credibility_score * 25)
                + max(0, 100 - (0.4 * age_hours))
            )
        db.commit()

        # Diversity-aware selection: up to max_per_category per category
        categories = [
            r[0]
            for r in db.execute(select(Category.name)).all()
        ]
        if not categories:
            categories = list(set(a.category for a in candidate_articles if a.category))

        final_ids = []
        for cname in categories:
            cat_sorted = sorted(
                [a for a in candidate_articles if a.category == cname],
                key=lambda x: x.rank_score or 0,
                reverse=True,
            )[:settings.TOP_NEWS_MAX_PER_CATEGORY]
            final_ids.extend(a.id for a in cat_sorted)

        # De-duplicate and take top N
        unique_ids = list(dict.fromkeys(final_ids))
        top_ids = sorted(
            unique_ids,
            key=lambda aid: next(
                (a.rank_score for a in candidate_articles if a.id == aid), 0
            ),
            reverse=True,
        )[: settings.TOP_NEWS_COUNT]

        if top_ids:
            db.execute(
                update(NewsArticle).where(NewsArticle.id.in_(top_ids)).values(flag="Y")
            )
            db.commit()

        complete_job(db, log, len(top_ids), 0)
        logger.info(f"[RANKING] Marked {len(top_ids)} articles as TOP NEWS (Y)")

    except Exception as exc:
        db.rollback()
        logger.error(f"[RANKING] Failed: {exc}")
        complete_job(db, log, 0, 0, str(exc))
    finally:
        db.close()
    _pipeline_banner("TOP-100 RANKING", start=False)


# =============================================
# TASK 4: AWS SYNC  (re-enabled)
# =============================================

@celery_app.task(name="app.tasks.celery_app.sync_to_aws")
def sync_to_aws():
    """
    Delta-sync local DB → AWS production DB.
    Syncs: categories → sources → articles (changed since last sync).
    Uses ON CONFLICT … DO UPDATE for safe idempotent upserts.
    """
    _pipeline_banner("AWS SYNC")
    db = get_db()
    log = log_job(db, "aws_sync")
    if not log:
        return

    # Guard: skip if AWS credentials not configured
    if not settings.AWS_DB_HOST or not settings.AWS_DB_USER or not settings.AWS_DB_PASSWORD:
        complete_job(db, log, 0, 0, "AWS credentials not configured — skipping")
        db.close()
        return

    try:
        conn = psycopg2.connect(
            host=settings.AWS_DB_HOST,
            port=settings.AWS_DB_PORT,
            dbname=settings.AWS_DB_NAME,
            user=settings.AWS_DB_USER,
            password=settings.AWS_DB_PASSWORD,
            connect_timeout=15,
        )
        conn.autocommit = True
        cur = conn.cursor()

        # ── 1. Categories ──
        try:
            cats = db.query(Category).all()
            for c in cats:
                cur.execute(
                    """
                    INSERT INTO categories (name, slug, description, article_count)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (name) DO UPDATE SET
                        description  = EXCLUDED.description,
                        article_count = EXCLUDED.article_count
                    """,
                    (c.name, c.slug, c.description, c.article_count),
                )
            logger.info(f"[AWS SYNC] Categories: {len(cats)} upserted")
        except Exception as exc:
            logger.warning(f"[AWS SYNC] Category sync warning: {exc}")

        # ── 2. News Sources ──
        try:
            sources = db.query(NewsSource).all()
            for s in sources:
                cur.execute(
                    """
                    INSERT INTO news_sources
                        (id, name, url, scraper_type, language, is_enabled, credibility_score, priority)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (id) DO UPDATE SET
                        name              = EXCLUDED.name,
                        url               = EXCLUDED.url,
                        is_enabled        = EXCLUDED.is_enabled,
                        credibility_score = EXCLUDED.credibility_score,
                        priority          = EXCLUDED.priority
                    """,
                    (
                        s.id, s.name, s.url, s.scraper_type, s.language,
                        s.is_enabled, s.credibility_score, s.priority,
                    ),
                )
            logger.info(f"[AWS SYNC] Sources: {len(sources)} upserted")
        except Exception as exc:
            logger.warning(f"[AWS SYNC] Source sync warning: {exc}")

        # ── 3. Articles (delta) ──
        meta = db.query(SyncMetadata).filter(SyncMetadata.target == "AWS_PROD").first()
        if not meta:
            meta = SyncMetadata(
                target="AWS_PROD",
                last_sync_at=datetime.datetime.now(timezone.utc) - timedelta(days=7),
            )
            db.add(meta)
            db.commit()

        records = (
            db.query(NewsArticle)
            .filter(NewsArticle.updated_at > meta.last_sync_at)
            .all()
        )

        if not records:
            cur.close()
            conn.close()
            complete_job(db, log, 0, 0, "No delta records")
            return

        ok = err = 0
        sync_at = datetime.datetime.now(timezone.utc)
        ARTICLE_UPSERT = """
            INSERT INTO news_articles (
                source_id, original_title, original_content, original_url,
                original_language, published_at, rephrased_title, rephrased_content,
                category, slug, tags, flag, image_url, author, content_hash,
                is_duplicate, duplicate_of_id, rank_score, created_at, updated_at
            ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (original_url) DO UPDATE SET
                rephrased_title   = EXCLUDED.rephrased_title,
                rephrased_content = EXCLUDED.rephrased_content,
                category          = EXCLUDED.category,
                slug              = EXCLUDED.slug,
                tags              = EXCLUDED.tags,
                flag              = EXCLUDED.flag,
                image_url         = EXCLUDED.image_url,
                rank_score        = EXCLUDED.rank_score,
                updated_at        = EXCLUDED.updated_at
        """
        for art in records:
            try:
                cur.execute(
                    ARTICLE_UPSERT,
                    (
                        art.source_id, art.original_title, art.original_content,
                        art.original_url, art.original_language, art.published_at,
                        art.rephrased_title, art.rephrased_content, art.category,
                        art.slug, art.tags, art.flag, art.image_url, art.author,
                        art.content_hash, art.is_duplicate, art.duplicate_of_id,
                        art.rank_score, art.created_at, art.updated_at,
                    ),
                )
                ok += 1
            except Exception as exc:
                logger.error(f"[AWS SYNC] Article {art.id} error: {exc}")
                err += 1

        cur.close()
        conn.close()

        meta.last_sync_at = sync_at
        meta.last_rows_ok = ok
        meta.last_rows_err = err
        db.commit()

        complete_job(db, log, ok, err)
        logger.info(f"[AWS SYNC] Done — {ok} OK, {err} ERR")

    except psycopg2.OperationalError as exc:
        logger.error(f"[AWS SYNC] Connection failed: {exc}")
        complete_job(db, log, 0, 0, f"Connection error: {exc}")
    except Exception as exc:
        logger.error(f"[AWS SYNC] Unexpected error: {exc}")
        complete_job(db, log, 0, 0, str(exc))
    finally:
        db.close()
    _pipeline_banner("AWS SYNC", start=False)


# =============================================
# TASK 5: CATEGORY COUNTS
# =============================================

@celery_app.task(name="app.tasks.celery_app.update_category_counts")
def update_category_counts():
    db = get_db()
    try:
        db.execute(
            text("""
                UPDATE categories c
                SET article_count = (
                    SELECT COUNT(*)
                    FROM news_articles a
                    WHERE a.category = c.name
                      AND a.flag != 'D'
                )
            """)
        )
        db.commit()
        logger.info("[CATEGORY] Counts refreshed")
    except Exception as exc:
        logger.error(f"[CATEGORY] Update failed: {exc}")
    finally:
        db.close()


# =============================================
# TASK 6: CLEANUP
# =============================================

@celery_app.task(name="app.tasks.celery_app.cleanup_old_articles")
def cleanup_old_articles():
    db = get_db()
    log = log_job(db, "maintenance")
    if not log:
        return
    try:
        cutoff = datetime.datetime.now(timezone.utc) - timedelta(days=15)
        res = db.execute(
            update(NewsArticle)
            .where(
                NewsArticle.created_at < cutoff,
                NewsArticle.flag != "D",
            )
            .values(flag="D", deleted_at=func.now())
        )
        db.commit()
        complete_job(db, log, res.rowcount, 0)
        logger.info(f"[CLEANUP] Soft-deleted {res.rowcount} old articles")
    except Exception as exc:
        logger.error(f"[CLEANUP] Error: {exc}")
        complete_job(db, log, 0, 0, str(exc))
    finally:
        db.close()


# =============================================
# TASK 7: SOCIAL POSTING
# =============================================

@celery_app.task(name="app.tasks.celery_app.post_to_social")
def post_to_social():
    """Post top-ranked articles to configured social media channels."""
    db = get_db()
    log = log_job(db, "social_post")
    if not log:
        return
    try:
        unposted = (
            db.query(NewsArticle)
            .filter(
                NewsArticle.flag == "Y",
                NewsArticle.is_posted_fb == False,
            )
            .order_by(NewsArticle.rank_score.desc())
            .limit(10)
            .all()
        )

        posted = 0
        for art in unposted:
            try:
                url = f"{settings.SOCIAL_SITE_URL}/news/{art.slug or art.id}"
                title = art.rephrased_title or art.original_title
                social_service.post_to_all(
                    art.id, title, art.rephrased_content or "", url
                )
                art.is_posted_fb = True
                art.is_posted_ig = True
                art.is_posted_x = True
                art.is_posted_wa = True
                posted += 1
            except Exception as exc:
                logger.warning(f"[SOCIAL] Article {art.id} post failed: {exc}")

        db.commit()
        complete_job(db, log, posted, 0)
        logger.info(f"[SOCIAL] Posted {posted} articles")

    except Exception as exc:
        logger.error(f"[SOCIAL] Error: {exc}")
        complete_job(db, log, 0, 0, str(exc))
    finally:
        db.close()


# =============================================
# TASK 8: FULL PIPELINE (manual trigger)
# =============================================

@celery_app.task(name="app.tasks.celery_app.run_full_pipeline")
def run_full_pipeline(source_id: Optional[int] = None):
    """
    Execute the complete news pipeline in sequence.
    Can be triggered manually from the Admin UI scheduler panel.
    Each step runs synchronously so logs are sequential.
    """
    _pipeline_banner("FULL INTEGRATED PIPELINE")
    start = time.time()

    # Step 1: Scrape
    logger.info("[PIPELINE] Step 1/5 — Scraping sources...")
    if source_id:
        scrape_source(source_id)
    else:
        scrape_all_sources()

    # Step 2: AI enrichment
    logger.info("[PIPELINE] Step 2/5 — AI enrichment...")
    process_ai_batch()

    # Step 3: Ranking
    logger.info("[PIPELINE] Step 3/5 — Updating Top-100 ranking...")
    update_top_100_ranking()

    # Step 4: AWS Sync
    logger.info("[PIPELINE] Step 4/5 — Syncing to AWS...")
    sync_to_aws()

    # Step 5: Social
    logger.info("[PIPELINE] Step 5/5 — Posting to social...")
    post_to_social()

    elapsed = time.time() - start
    logger.info(
        f"\n{'=' * 60}\n"
        f"  FULL PIPELINE COMPLETE in {elapsed:.1f}s\n"
        f"  Time: {datetime.datetime.now(timezone.utc).isoformat()}\n"
        f"{'=' * 60}"
    )


# =============================================
# STANDALONE RUNNER
# =============================================

if __name__ == "__main__":
    import sys

    commands = {
        "--run":           run_full_pipeline,
        "--scrape":        scrape_all_sources,
        "--ai":            process_ai_batch,
        "--rank":          update_top_100_ranking,
        "--aws":           sync_to_aws,
        "--social":        post_to_social,
        "--cleanup":       cleanup_old_articles,
        "--cat-counts":    update_category_counts,
    }

    if len(sys.argv) > 1 and sys.argv[1] in commands:
        fn = commands[sys.argv[1]]
        print(f"Running: {fn.__name__}")
        fn()
    else:
        print("Usage: python -m app.tasks.celery_app <command>")
        print("Commands:", ", ".join(commands.keys()))
