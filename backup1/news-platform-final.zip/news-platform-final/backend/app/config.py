"""
Application Configuration
Single source of truth for all settings.
Categories here MUST match frontend CATS in App.js and category_service.py CANONICAL_CATEGORIES.
"""
from pydantic_settings import BaseSettings
from pydantic import ConfigDict
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    model_config = ConfigDict(env_file=".env", case_sensitive=True, frozen=False)

    # ─── App ───────────────────────────────────────────────────────────────
    APP_NAME: str = "News Aggregation Platform"
    APP_VERSION: str = "2.1.0"
    DEBUG: bool = True
    SECRET_KEY: str = "your-secret-key-change-in-production-abc123xyz"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 24 hours

    # ─── CANONICAL CATEGORIES — keep in sync with frontend CATS & category_service ───
    CATEGORIES: List[str] = [
        "Politics", "Business", "Technology", "Sports", "Entertainment",
        "Health", "Science", "Education", "Crime", "International",
        "Environment", "Lifestyle", "Religion", "Agriculture", "Home"
    ]

    # ─── Database ──────────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://newsadmin:newspass123@localhost:5432/newsagg"
    DATABASE_URL_SYNC: str = "postgresql://newsadmin:newspass123@localhost:5432/newsagg"
    AWS_DATABASE_URL: str = ""

    # AWS DB connection fields (for psycopg2 direct sync)
    AWS_DB_HOST: str = "32.193.27.142"
    AWS_DB_PORT: int = 5432
    AWS_DB_NAME: str = "news_db_fe"
    AWS_DB_USER: str = ""
    AWS_DB_PASSWORD: str = ""

    # ─── Redis ─────────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"

    # ─── AI Services ───────────────────────────────────────────────────────
    GEMINI_API_KEY: str = ""
    GEMINI_API_KEY_SECONDARY: str = ""
    ANTHROPIC_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    GROQ_API_KEY: str = ""
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3"
    AI_PROVIDER: str = "ollama"

    # Provider chain — tried in order, first success wins
    AI_PROVIDER_CHAIN: List[str] = ["gemini", "openai"]
    AI_BATCH_SIZE: int = 100
    AI_CONCURRENCY: int = 15
    AI_MAX_RETRIES: int = 2
    AI_SIMILARITY_THRESHOLD: float = 0.90

    # ─── Scraping ──────────────────────────────────────────────────────────
    SCRAPE_TIMEOUT: int = 30
    MAX_ARTICLES_PER_SCRAPE: int = 200
    USER_AGENT: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    )

    # ─── Processing / Ranking ──────────────────────────────────────────────
    TOP_NEWS_COUNT: int = 100
    TOP_NEWS_MAX_AGE_DAYS: int = 60
    TOP_NEWS_MIN_PER_CATEGORY: int = 3
    TOP_NEWS_MAX_PER_CATEGORY: int = 25
    DUPLICATE_SIMILARITY_THRESHOLD: float = 0.85

    # ─── Social Posting ────────────────────────────────────────────────────
    SOCIAL_POST_ENABLED: bool = True
    SOCIAL_SITE_URL: str = "https://www.peoples-feedback.com"
    SCHEDULE_SOCIAL_ENABLED: bool = True
    SCHEDULE_SOCIAL_MINUTES: str = "12,42"

    FB_PAGE_ACCESS_TOKEN: str = ""
    FB_PAGE_ID: str = ""
    IG_BUSINESS_ACCOUNT_ID: str = ""
    X_API_KEY: str = ""
    X_API_SECRET: str = ""
    X_ACCESS_TOKEN: str = ""
    X_ACCESS_SECRET: str = ""
    WA_PHONE_NUMBER_ID: str = ""
    WA_ACCESS_TOKEN: str = ""
    WA_RECIPIENT_GROUP: str = ""

    # ─── CORS ──────────────────────────────────────────────────────────────
    CORS_ORIGINS: list = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:80",
    ]

    # ─── News source filter ────────────────────────────────────────────────
    ENABLED_SOURCES: str = ""

    # ─── SCHEDULER MASTER SWITCH ───────────────────────────────────────────
    SCHEDULER_ENABLED: bool = True

    # Per-job enable flags
    SCHEDULE_SCRAPE_ENABLED: bool = True
    SCHEDULE_AI_ENABLED: bool = True
    SCHEDULE_RANKING_ENABLED: bool = True
    SCHEDULE_AWS_SYNC_ENABLED: bool = True        # ← now enabled by default
    SCHEDULE_CATEGORY_COUNT_ENABLED: bool = True
    SCHEDULE_CLEANUP_ENABLED: bool = True

    # Cron minute expressions — comma-separated values (e.g. "0,30" = :00 and :30)
    SCHEDULE_SCRAPE_MINUTES: str = "0,30"        # every 30 min
    SCHEDULE_AI_MINUTES: str = "5,35"            # 5 min after scrape
    SCHEDULE_RANKING_MINUTES: str = "10,40"      # 5 min after AI
    SCHEDULE_AWS_SYNC_MINUTES: str = "15,45"     # 5 min after ranking
    SCHEDULE_CATEGORY_MINUTES: str = "20,50"     # maintenance
    SCHEDULE_CLEANUP_MINUTES: str = "25,55"      # maintenance


@lru_cache()
def get_settings() -> Settings:
    return Settings()
