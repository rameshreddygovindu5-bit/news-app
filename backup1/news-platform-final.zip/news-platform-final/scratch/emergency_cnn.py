
import sys
import os
import asyncio
import logging
from datetime import datetime, timezone

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.database import SyncSessionLocal
from app.models.models import NewsSource, NewsArticle
from app.scrapers.cnn_scraper import CNNScraper
import hashlib
import re

async def emergency_inject():
    print("--- EMERGENCY CNN INJECTION ---")
    
    with SyncSessionLocal() as session:
        cnn_source = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).first()
        if not cnn_source:
            print("CNN Source not found.")
            return
            
        source_id = cnn_source.id
        scraper = CNNScraper({"scraper_config": {"max_articles": 5, "section_max_pages": 1}})
        
        print(f"Collecting 5 links...")
        links = await scraper.collect_all_links()
        links = links[:5]
        
        inserted = 0
        for link in links:
            # Check for existing article by URL to avoid UniqueViolation
            existing = session.query(NewsArticle).filter(NewsArticle.original_url == link['url']).first()
            if existing:
                print(f"Skipping (already exists): {link['title']}")
                continue
                
            print(f"Fetching: {link['title']}")
            data = await scraper.fetch_article_content(link['url'])
            
            title = data['title'] or link['title']
            content = data['content'] or title
            
            c_hash = hashlib.sha256(f"{source_id}{title.lower()}".encode()).hexdigest()
            
            clean = re.sub(r"[^\w\s-]", "", title.lower()).strip().replace(" ", "-")[:100]
            url_hash = hashlib.md5(link['url'].encode()).hexdigest()[:6]
            slug = f"{clean}-{url_hash}"

            new_art = NewsArticle(
                source_id=source_id,
                original_title=title,
                original_content=content,
                original_url=link['url'],
                original_language="en",
                published_at=datetime.now(timezone.utc),
                image_url=data.get('image_url') or link.get('image_url'),
                content_hash=c_hash,
                is_duplicate=False,
                flag="Y",  # Force to Top News
                ai_status="completed", # Skip AI for instant visibility
                rephrased_title=title,
                rephrased_content=content,
                category="World",
                slug=slug,
            )
            session.add(new_art)
            session.commit()
            inserted += 1
            print(f"Saved: {title}")

    print(f"\nFINISHED: Injected {inserted} articles.")

if __name__ == "__main__":
    asyncio.run(emergency_inject())
