
import sys
import os
import logging

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.tasks.celery_app import process_ai_batch
from app.database import SyncSessionLocal
from app.models.models import NewsArticle, NewsSource

def trigger_ai_process():
    logging.basicConfig(level=logging.INFO)
    print("--- STARTING AI REPHRASE TASK ---")
    
    with SyncSessionLocal() as session:
        cnn_source = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).first()
        # Reset articles that need processing
        session.query(NewsArticle).filter(
            NewsArticle.ai_status.in_(["completed", "failed", "processing"])
        ).filter(
            NewsArticle.source_id == cnn_source.id if cnn_source else True
        ).update({"ai_status": "pending"})
        session.commit()
        print("Reset AI statuses to 'pending' for CNN/stuck articles.")

        # Check total pending
        pending_count = session.query(NewsArticle).filter(NewsArticle.ai_status == "pending").count()
        print(f"Total articles waiting for AI: {pending_count}")
        
        if pending_count == 0:
            print("No pending articles to process.")
            return

        # Trigger the official batch process
        print("Starting AI batch processing (this may take a minute)...")
        process_ai_batch()
        
    print("\n--- AI PROCESSING TASK COMPLETE ---")

if __name__ == "__main__":
    trigger_ai_process()
