
import sys
import os
from sqlalchemy import delete

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.database import SyncSessionLocal
from app.models.models import NewsArticle, NewsSource

def cleanup_cnn_articles():
    with SyncSessionLocal() as session:
        # Find all sources related to CNN
        cnn_sources = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).all()
        source_ids = [s.id for s in cnn_sources]
        
        if not source_ids:
            print("No CNN sources found in database.")
            return

        print(f"Found CNN Source IDs: {source_ids}")
        
        # Delete articles
        stmt = delete(NewsArticle).where(NewsArticle.source_id.in_(source_ids))
        result = session.execute(stmt)
        session.commit()
        
        print(f"Successfully deleted {result.rowcount} CNN articles.")

if __name__ == "__main__":
    cleanup_cnn_articles()
