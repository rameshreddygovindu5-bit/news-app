
import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.database import SyncSessionLocal
from app.models.models import NewsArticle

def reset_stuck_ai():
    with SyncSessionLocal() as session:
        # Reset any stuck articles
        res = session.query(NewsArticle).filter(NewsArticle.ai_status == "processing").update({"ai_status": "pending"})
        session.commit()
        print(f"Reset {res} articles from 'processing' back to 'pending'.")

if __name__ == "__main__":
    reset_stuck_ai()
