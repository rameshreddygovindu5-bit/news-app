
import sys
import os
import asyncio
import logging
from datetime import datetime, timezone

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.tasks.celery_app import worker_scrape_source
from app.database import SyncSessionLocal
from app.models.models import NewsSource, NewsArticle

async def fast_track_cnn():
    logging.basicConfig(level=logging.INFO)
    print("--- FAST-TRACK CNN SCRAPE (TOP 20) ---")
    
    with SyncSessionLocal() as session:
        cnn_source = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).first()
        if not cnn_source:
            print("CNN Source not found.")
            return
            
        source_id = cnn_source.id
        # Temporarily limit the scraper config to 20 for instant visibility
        orig_config = cnn_source.scraper_config or {}
        cnn_source.scraper_config = {**orig_config, "max_articles": 20, "section_max_pages": 1}
        session.commit()
        
        print(f"Triggering small batch (20 articles) for ID: {source_id}...")
        res = worker_scrape_source(source_id, "manual-fast-track")
        
        print(f"\nSUCCESS: Inserted {res.get('inserted', 0)} fresh articles.")
        
        # Restore configuration
        cnn_source.scraper_config = orig_config
        session.commit()

if __name__ == "__main__":
    # Remove asyncio.run because worker_scrape_source handles its own loop
    import logging
    logging.basicConfig(level=logging.INFO)
    
    with SyncSessionLocal() as session:
        cnn_source = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).first()
        if not cnn_source:
            print("CNN Source not found.")
            sys.exit(1)
            
        source_id = cnn_source.id
        orig_config = cnn_source.scraper_config or {}
        cnn_source.scraper_config = {**orig_config, "max_articles": 20, "section_max_pages": 1}
        session.commit()
        
        print(f"Triggering small batch (20 articles) for ID: {source_id}...")
        # Now calling correctly
        from app.tasks.celery_app import worker_scrape_source
        res = worker_scrape_source(source_id, "manual-fast-track")
        
        print(f"\nSUCCESS: Inserted {res.get('inserted', 0)} fresh articles.")
        
        cnn_source.scraper_config = orig_config
        session.commit()
