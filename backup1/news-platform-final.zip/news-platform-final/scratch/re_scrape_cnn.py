
import sys
import os
import asyncio

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.services.news_service import NewsService
from app.database import SyncSessionLocal
from app.models.models import NewsSource

async def trigger_cnn_scrape():
    print("--- Starting Manual CNN Scrape Trigger ---")
    
    with SyncSessionLocal() as session:
        # Find CNN source
        cnn_source = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).first()
        if not cnn_source:
            print("CNN Source not found.")
            return
            
        print(f"Triggering for source: {cnn_source.name} (ID: {cnn_source.id})")
        
        service = NewsService()
        # We run the scrape directly instead of through Celery to see the output here
        articles = await service.scrape_source(cnn_source)
        
        print(f"\nSuccessfully scraped and saved {len(articles)} articles.")
        if articles:
            print(f"Sample Article: {articles[0].title}")
            print(f"Content Length: {len(articles[0].content or '')}")

if __name__ == "__main__":
    asyncio.run(trigger_cnn_scrape())
