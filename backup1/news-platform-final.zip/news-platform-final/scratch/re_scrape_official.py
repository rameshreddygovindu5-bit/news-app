
import sys
import os
import logging

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from app.tasks.celery_app import worker_scrape_source
from app.database import SyncSessionLocal
from app.models.models import NewsSource

def run_manual_cnn_scrape():
    logging.basicConfig(level=logging.INFO)
    print("--- RE-SCRAPING CNN FOR RELOAD ---")
    
    with SyncSessionLocal() as session:
        cnn_source = session.query(NewsSource).filter(NewsSource.name.ilike("%cnn%")).first()
        if not cnn_source:
            print("CNN Source not found.")
            return
            
        source_id = cnn_source.id
        print(f"Starting scrape for Source ID: {source_id} ({cnn_source.name})")
        
        # Trigger the official worker function
        res = worker_scrape_source(source_id, "manual-reload")
        
        print("\n--- SCRAPE FINISHED ---")
        print(f"Articles Inserted: {res.get('inserted', 0)}")
        print(f"Errors occurred: {res.get('errors', 0)}")

if __name__ == "__main__":
    run_manual_cnn_scrape()
